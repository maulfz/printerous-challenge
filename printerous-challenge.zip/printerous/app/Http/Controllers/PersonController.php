<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Organization;
use App\Person;

class PersonController extends Controller
{

    public function index()
    {
        $DataPersons = Person::all();
        return view('admin/person', compact('DataPersons'));
    }

    public function create($id)
    {
		$organization_id = $id;
        return view('admin/add_person', compact('organization_id'));
    }

    public function store(Request $request)
    {
		$name = null;
        if ($request->hasfile('filename')) {
            $file = $request->file('filename');
            $name = time() . $file->getClientOriginalName();
            $file->move(public_path() . '/images/', $name);
        }
        $person = new Person;
        $person->name = $request->get('name');
        $person->phone = $request->get('phone');
        $person->email = $request->get('email');
        $person->organization__id = $request->get('organization__id');
        $person->avatar = $name;
        $person->save();

        return redirect('organization/'.$person->organization__id.'/edit')->with('success', 'PIC has been added');
    }

    public function edit($id)
    {
        $person = Person::find($id);
        return view('admin/edit_person', compact('person', 'id'));
    }

    public function destroy($id)
    {
        $person = Person::find($id);
        $organizationId = $person->organization__id;
        $person->delete();
        return redirect('organization/'.$organizationId.'/edit')->with('success', 'PIC has been deleted');
    }

    public function update(Request $request, $id)
    {
        // dd($request);
        $person = Person::find($id);
        $person->name = $request->get('name');
        $person->phone = $request->get('phone');
        $person->email = $request->get('email');
        $person->save();
        return redirect('organization/'.$person->organization__id.'/edit')->with('success', 'PIC has been updated');
    }
}
