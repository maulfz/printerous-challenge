<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Organization;
use App\Person;

class OrganizationController extends Controller
{

    public function index()
    {
        $DataOrganizations = Organization::all();
        return view('admin/organization', compact('DataOrganizations'));
    }

    public function create()
    {
        // return 23;
        return view('admin/add_organization');
    }

    public function store(Request $request)
    {
		$name = null;
        if ($request->hasfile('filename')) {
            $file = $request->file('filename');
            $name = time() . $file->getClientOriginalName();
            $file->move(public_path() . '/images/', $name);
        }
        $organization = new Organization;
        $organization->name = $request->get('name');
        $organization->phone = $request->get('phone');
        $organization->email = $request->get('email');
        $organization->website = $request->get('website');
        $organization->logo = $name;
        $organization->save();

        return redirect('organization')->with('success', 'Organization has been added');
    }

    public function edit($id)
    {
        $organization = Organization::find($id);
        //$person = Person::find($id);
        $person = Person::where('organization__id', $id)
                ->get();
        return view('admin/edit_organization', compact('organization', 'person', 'id'));
    }

    public function destroy($id)
    {
        $organization = Organization::find($id);
        Person::where('organization__id', $id)->delete();
        $organization->delete();
        return redirect('organization')->with('success', 'Organization has been  deleted');
    }

    public function update(Request $request, $id)
    {
        // dd($request);
        $organization = Organization::find($id);
        $organization->name = $request->get('name');
        $organization->phone = $request->get('phone');
        $organization->email = $request->get('email');
        $organization->website = $request->get('website');
        $organization->save();
        return redirect('organization')->with('success', 'Organization has been updated');
    }
}
