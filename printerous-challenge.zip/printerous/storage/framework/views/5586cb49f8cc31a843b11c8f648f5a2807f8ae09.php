<!DOCTYPE html>
<html>
<head>
    <title>Laravel 5.5 Ajax CRUD</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css">
</head>
<body>
    <div class="container">
        <div class="card card-block">
            <h2 class="card-title">Laravel AJAX Examples
                <small>via jQuery .ajax()</small>
            </h2>
            <p class="card-text">Learn how to handle ajax with Laravel and jQuery.</p>
            <button type="button" id="btn-add" name="btn-add" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#create-item">Add New Post</button>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                <th>Title</th>
                <th>Details</th>
                <th width="200px">Action</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $Posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $DataPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <th scope="row"><?php echo e($key += 1); ?></th> -->
                            <td><?php echo e($DataPost->title); ?></td>
                            <td><?php echo e($DataPost->details); ?></td>
                            <td data-id=<?php echo e($DataPost->id); ?>><button data-toggle="modal" data-target="#edit-item" class="btn btn-primary edit-item">Edit</button>
                            <button class="btn btn-danger remove-item">Delete</button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <ul id="pagination" class="pagination-sm"></ul>

        <div class="modal fade" id="create-item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Create</h4>
              </div>
              <div class="modal-body">
                    <form data-toggle="validator" action="<?php echo e(url('posts')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="control-label" for="title">TITLE :</label>
                            <input type="text" name="title" class="form-control" data-error="Please enter title." required />
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="title">DESCRIPTION :</label>
                            <textarea name="details" class="form-control" data-error="Please enter description." required></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn crud-submit btn-success">Submit</button>
                        </div>
                    </form>
              </div>
            </div>
          </div>
        </div>

        <div class="modal fade" id="edit-item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Edit Data</h4>
              </div>
              <div class="modal-body">
                    <form data-toggle="validator" action="<?php echo e(url('post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="_method" type="hidden" value="PUT">
                        <div class="form-group">
                            <label class="control-label" for="title">TITLE :</label>
                            <input type="text" name="title" class="form-control" data-error="Please enter title." required />
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="title">DESCRIPTION :</label>
                            <textarea name="details" class="form-control" data-error="Please enter description." required></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success crud-submit-edit">Submit</button>
                        </div>
                    </form>
              </div>
            </div>
          </div>
        </div>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <script type="text/javascript">
        var url = "<?php echo url('posts') ?>";
    </script>
    <script src="js/crud-ajax.js"></script>
</body>
</html>
