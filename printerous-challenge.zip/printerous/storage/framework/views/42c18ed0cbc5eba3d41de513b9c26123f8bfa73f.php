<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                <div class="card-header">Edit Profile</div>
<br/><br/>
<form method="post" action="<?php echo e(url('adminprofile', $id)); ?>">
        <?php echo csrf_field(); ?>
        <input name="_method" type="hidden" value="PUT">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Name">Nama:</label>
            <input type="text" class="form-control" name="nama" value="<?php echo e($Profile->nama); ?>" required>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Notelp">No Telpon:</label>
            <input type="text" class="form-control" name="no_telp" value="<?php echo e($Profile->no_telp); ?>" required>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Email">Email:</label>
            <input type="text" class="form-control" name="email" value="<?php echo e($Profile->email); ?>" required>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Email">Alamat:</label>
              <textarea class="form-control" name="alamat" value="<?php echo e($Profile->alamat); ?>" required><?php echo e($Profile->alamat); ?></textarea>
            </div>
          </div>
<div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
          </div>
        </div>
      </form>
    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
        $('#datepicker').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy'
         });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>