<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
				<div class="card-body">
				  <div class="card-header">Edit PIC</div>
					<br/><br/>
					<form method="post" action="<?php echo e(url('person', $id)); ?>">
						<?php echo csrf_field(); ?>
						<input name="_method" type="hidden" value="PUT">
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4">
							<label for="name">Name:</label>
							<input type="text" class="form-control" name="name" value="<?php echo e($person->name); ?>">
						  </div>
						</div>
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4">
							<label for="phone">Phone:</label>
							<input type="text" class="form-control" name="phone" value="<?php echo e($person->phone); ?>">
						  </div>
						</div>
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4">
							<label for="email">Email:</label>
							<input type="text" class="form-control" name="email" value="<?php echo e($person->email); ?>">
						  </div>
						</div>
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4" align="right">
							<button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
						  </div>
						</div>
					  </form>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>