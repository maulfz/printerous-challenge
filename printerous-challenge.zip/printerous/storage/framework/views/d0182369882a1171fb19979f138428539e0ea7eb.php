<?php $__env->startSection('title', 'Detail Blog Project'); ?>
<?php $__env->startSection('menu'); ?>
##parent-placeholder-252a25667dc7c65fe0e9bf62d474bbab9bab4068##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="side-body">
    <h3 style="color:red;">Detail Blog Project</h3>
    <hr><br>

    <div class="row">
            <div class="col-md-12">
                <div class="card-content">
                    <div class="card-img">
                        <!--<img src="https://placeimg.com/380/230/nature" alt="">-->
						<img src="<?php echo e(asset('images') . '/' . $Blog->image_name); ?>" alt="">
                        <span><h4><?php echo e($Blog->created_at); ?></h4></span>
                    </div>
                    <div class="card-desc">
                        <h3><?php echo e($Blog->title); ?></h3>
                        <p><?php echo e($Blog->description); ?></p>
                    </div>
                </div>
            </div>
          </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>