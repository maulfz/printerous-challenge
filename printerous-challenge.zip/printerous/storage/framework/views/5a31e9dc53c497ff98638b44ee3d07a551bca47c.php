<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Data User</div>
            <div class="panel-body">
                <a class="btn btn-success" href="<?php echo e(action('UserController@create')); ?>">Tambah User</a>
                <table class="table table-bordered table-hover" style="margin-top:10px">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $a=1;
                        ?>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e((($user->currentPage()-1)*$user->perPage())+$a++); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e(!empty($row->role->nama)?$row->role->nama:"-"); ?></td>
                            <td>
                                <a href="<?php echo e(action('UserController@edit',['id'=>$row->id])); ?>" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-pencil"></i></a>
                                <form action="<?php echo e(action('UserController@destroy',['id'=>$row->id])); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button class="btn btn-xs btn-danger" title="Delete InspTemuanItem" onclick="return confirm('Confirm delete?')" type="submit">
                                        <i class="glyphicon glyphicon-trash"></i>
                                    </button>   
                                </form> 
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>