<?php $__env->startSection('content'); ?>
<div class="container">
<?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
     <?php endif; ?>
    <div class="row justify-content-center">
        <div class="right">
    <a href="<?php echo e(url('admin/add_profile')); ?>" class="btn btn-primary">Add New Profile</a><br/><br/>
</div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Profile</div>
                <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">No Telpon</th>
                        <th scope="col">Alamat</th>
                        <th scope="col" colspan="2">Action</th>

                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $DataProfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $DataProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key += 1); ?></th>
                            <td><?php echo e($DataProfile->nama); ?></td>
                            <td><?php echo e($DataProfile->email); ?></td>
                            <td><?php echo e($DataProfile->no_telp); ?></td>
                            <td><?php echo e($DataProfile->alamat); ?></td>
                            <td><a href="<?php echo e(url('admin/edit_profile', $DataProfile->id)); ?>" class="btn btn-success">Edit</a></td>
                            <td>
                            <form action="<?php echo e(url('adminprofile',$DataProfile->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input name="_method" type="hidden" value="DELETE">
                                <button onclick="return confirm('Are you sure?')" class="btn btn-danger" type="submit">Delete</button>
                            </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>