<?php $__env->startSection('title', 'Blog Project'); ?>
<?php $__env->startSection('menu'); ?>
##parent-placeholder-252a25667dc7c65fe0e9bf62d474bbab9bab4068##
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="side-body">
    <h3>Blog PBW Project</h3>
    <hr><br>
    <div class="row">

            <?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4" style="margin-bottom:20px;">
                <div class="card-content">
                    <div class="card-img">
                        <!--<img src="https://placeimg.com/380/230/nature" alt="">-->
                        <img src="<?php echo e(asset('images') . '/' . $blog->image_name); ?>" alt="">
                        <span><h4><?php echo e($blog->created_at); ?></h4></span>
                    </div>
                    <div class="card-desc">
                        <h3><?php echo e($blog->title); ?></h3>
                        <p><?php echo e($blog->description); ?></p>
                            <a href="detail/<?php echo e($blog->id); ?>" class="btn-card">Read</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>