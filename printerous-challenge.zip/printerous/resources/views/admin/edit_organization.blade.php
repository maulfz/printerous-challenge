@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
				<div class="card-body">
				  <div class="card-header">Edit Organization</div>
					<br/><br/>
					<form method="post" action="{{url('organization', $id)}}">
						@csrf
						<input name="_method" type="hidden" value="PUT">
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4">
							<label for="name">Name:</label>
							<input type="text" class="form-control" name="name" value="{{$organization->name}}">
						  </div>
						</div>
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4">
							<label for="phone">Phone:</label>
							<input type="text" class="form-control" name="phone" value="{{$organization->phone}}">
						  </div>
						</div>
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4">
							<label for="email">Email:</label>
							<input type="text" class="form-control" name="email" value="{{$organization->email}}">
						  </div>
						</div>
						<div class="row">
						  <div class="col-md-4"></div>
							<div class="form-group col-md-4">
							  <label for="website">Website</label>
							  <textarea class="form-control" name="website">{{ $organization->website }}</textarea>
							</div>
						  </div>
						<div class="row">
						  <div class="col-md-4"></div>
						  <div class="form-group col-md-4" align="right">
							<button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
						  </div>
						</div>
					  </form>
					</div>
					@if (\Session::has('success'))
					  <div class="alert alert-success">
						<p>{{ \Session::get('success') }}</p>
					  </div><br />
					 @endif
					<div class="row justify-content-center">
					<div class="right" align="right">
						<a href="{{ URL::to('person/' . $organization->id . '/create') }}" class="btn btn-primary">Add New PIC</a><br/><br/>
					</div>
							<div class="col-md-12">
								<div class="card">
									<div class="card-header">PIC</div>
									<div class="card-body">
									<table class="table">
										<thead>
											<tr>
											<th scope="col">#</th>
											<th scope="col">Name</th>
											<th scope="col">Email</th>
											<th scope="col">Phone</th>
											<th scope="col">Created</th>
											<th scope="col" colspan="2">Action</th>

											</tr>
										</thead>
										<tbody>

											@foreach($person as $key => $OrganizationPerson)
											<tr>
												<th scope="row">{{ $key += 1 }}</th>
												<td>{{ $OrganizationPerson->name }}</td>
												<td>{{ $OrganizationPerson->phone }}</td>
												<td>{{ $OrganizationPerson->email }}</td>
												<td>{{ $OrganizationPerson->created_at }}</td>
												<td><a href="{{ URL::to('person/' . $OrganizationPerson->id . '/edit') }}" class="btn btn-success">Edit</a></td>
												<td>
												<form action="{{url('/person',$OrganizationPerson->id)}}" method="post">
													@csrf
													<input name="_method" type="hidden" value="DELETE">
													<button onclick="return confirm('Are you sure?')" class="btn btn-danger" type="submit">Delete</button>
												</form>
												</td>
											</tr>
											@endforeach

										</tbody>
									</table>
									</div>
								</div>
							</div>
						</div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
